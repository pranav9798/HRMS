export default function LeaveTab(){

    return(

        <p align="center">LeaveTab</p>
    );

 }